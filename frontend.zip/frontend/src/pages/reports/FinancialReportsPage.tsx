import { useEffect, useMemo, useState } from 'react'
import { useLocation, useSearchParams } from 'react-router-dom'
import { useAppSelector } from '../../app/hooks'
import {
  useGetAccountsQuery,
  useGetBalanceSheetReportQuery,
  useGetBusinessesQuery,
  useGetCustomerBalancesReportQuery,
  useGetGeneralLedgerReportQuery,
  useGetProfitLossReportQuery,
  useGetStationsQuery,
  useGetSupplierBalancesReportQuery,
  useGetTrialBalanceReportQuery,
} from '../../app/api/apiSlice'
import { DataTable, type Column } from '../../components/DataTable'
import { FormSelect, type SelectOption } from '../../components/FormSelect'
import { isAccountsPayable, isAccountsReceivable } from '../../lib/accountingSubledger'
import { formatDecimal } from '../../lib/formatNumber'
import {
  filterAccountsForFinancialReportsPicker,
  filterAccountsForViewer,
  filterBusinessLeafAccounts,
} from '../../lib/accountScope'
import {
  adminNeedsSettingsStation,
  SETTINGS_STATION_HINT,
  showStationPickerInForms,
  useEffectiveStationId,
} from '../../lib/stationContext'
import { BalanceSheetReportView } from './BalanceSheetReportView'
import { ProfitLossReportView } from './ProfitLossReportView'

type ReportKind = 'trial' | 'ledger' | 'pl' | 'bs' | 'customer' | 'supplier' | 'daily-cash-flow'

const REPORT_KINDS: ReportKind[] = ['trial', 'ledger', 'pl', 'bs', 'customer', 'supplier', 'daily-cash-flow']

function parseKindParam(v: string | null): ReportKind | null {
  if (!v) return null
  return REPORT_KINDS.includes(v as ReportKind) ? (v as ReportKind) : null
}

function reportKindFromPathname(pathname: string): ReportKind | null {
  switch (pathname) {
    case '/financial-reports/trial-balance':
      return 'trial'
    case '/financial-reports/general-ledger':
      return 'ledger'
    case '/financial-reports/profit-and-loss':
      return 'pl'
    case '/financial-reports/balance-sheet':
      return 'bs'
    case '/financial-reports/customer-balances':
      return 'customer'
    case '/financial-reports/supplier-balances':
      return 'supplier'
    case '/financial-reports/daily-cash-flow':
      return 'daily-cash-flow'
    default:
      return null
  }
}

function formatReportPeriod(from: string, to: string): string {
  if (!from && !to) return 'All periods'
  const o: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric', year: 'numeric' }
  try {
    if (from && to) {
      const a = new Date(`${from}T12:00:00`)
      const b = new Date(`${to}T12:00:00`)
      return `${a.toLocaleDateString(undefined, o)} – ${b.toLocaleDateString(undefined, o)}`
    }
    if (from) return `From ${new Date(`${from}T12:00:00`).toLocaleDateString(undefined, o)}`
    return `Through ${new Date(`${to}T12:00:00`).toLocaleDateString(undefined, o)}`
  } catch {
    return 'Selected period'
  }
}

interface TrialBalanceRow {
  id: number
  code: string
  name: string
  debit: number
  credit: number
  balance: number
}

/** Customer sub-ledger row; columns mirror trial balance (code / name / debit-like / credit-like / balance). */
interface CustomerBalanceRow {
  id: number
  code: string
  name: string
  given: number
  paid: number
  balance: number
}

export function FinancialReportsPage() {
  const location = useLocation()
  const [searchParams] = useSearchParams()
  const role = useAppSelector((s) => s.auth.role)
  const authBusinessIdRaw = useAppSelector((s) => s.auth.businessId)
  const authBusinessId = authBusinessIdRaw ?? 0
  const isSuperAdmin = role === 'SuperAdmin'
  const effectiveStationId = useEffectiveStationId()
  const showStationPicker = showStationPickerInForms(role)
  const needsReportStation = !showStationPicker && (effectiveStationId == null || effectiveStationId <= 0)
  const showSettingsStationHint = adminNeedsSettingsStation(role, effectiveStationId)
  const reportStationBlockedMessage = needsReportStation
    ? showSettingsStationHint
      ? SETTINGS_STATION_HINT
      : 'Your account has no station assigned. Contact an administrator.'
    : null

  const reportStationId = (stateId: number | null) =>
    showStationPicker ? (stateId != null && stateId > 0 ? stateId : undefined) : effectiveStationId != null && effectiveStationId > 0 ? effectiveStationId : undefined

  const urlKind =
    reportKindFromPathname(location.pathname) ?? parseKindParam(searchParams.get('kind'))
  const [kind, setKind] = useState<ReportKind>(urlKind ?? 'trial')

  useEffect(() => {
    const k =
      reportKindFromPathname(location.pathname) ?? parseKindParam(searchParams.get('kind'))
    if (k) setKind(k)
  }, [location.pathname, searchParams])

  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [trialBusinessId, setTrialBusinessId] = useState<number | null>(null)
  const [trialStationId, setTrialStationId] = useState<number | null>(null)
  const [trialPage, setTrialPage] = useState(1)
  const [trialPageSize, setTrialPageSize] = useState(50)
  const [trialSearch, setTrialSearch] = useState('')
  const [trialSelected, setTrialSelected] = useState<Set<number>>(new Set())

  const [plBusinessId, setPlBusinessId] = useState<number | null>(null)
  const [plStationId, setPlStationId] = useState<number | null>(null)
  const [ledgerBusinessId, setLedgerBusinessId] = useState<number | null>(null)
  const [ledgerStationId, setLedgerStationId] = useState<number | null>(null)
  const [ledgerAccountId, setLedgerAccountId] = useState<number | null>(null)
  const [bsBusinessId, setBsBusinessId] = useState<number | null>(null)
  const [bsStationId, setBsStationId] = useState<number | null>(null)
  const [customerBusinessId, setCustomerBusinessId] = useState<number | null>(null)
  const [customerStationId, setCustomerStationId] = useState<number | null>(null)
  const [customerPage, setCustomerPage] = useState(1)
  const [customerPageSize, setCustomerPageSize] = useState(50)
  const [customerSearch, setCustomerSearch] = useState('')
  const [customerFrom, setCustomerFrom] = useState('')
  const [customerTo, setCustomerTo] = useState('')
  const [customerReceivableAccountId, setCustomerReceivableAccountId] = useState<number | null>(null)
  const [customerApplied, setCustomerApplied] = useState<{
    businessId: number
    stationId?: number
    from?: string
    to?: string
    receivableAccountId: number
  } | null>(null)
  const [customerSelected, setCustomerSelected] = useState<Set<number>>(new Set())

  const [supplierBusinessId, setSupplierBusinessId] = useState<number | null>(null)
  const [supplierStationId, setSupplierStationId] = useState<number | null>(null)
  const [supplierFrom, setSupplierFrom] = useState('')
  const [supplierTo, setSupplierTo] = useState('')
  const [supplierPayableAccountId, setSupplierPayableAccountId] = useState<number | null>(null)
  const [supplierApplied, setSupplierApplied] = useState<{
    businessId: number
    stationId?: number
    from?: string
    to?: string
    payableAccountId: number
  } | null>(null)
  const [supplierPage, setSupplierPage] = useState(1)
  const [supplierPageSize, setSupplierPageSize] = useState(50)
  const [supplierSearch, setSupplierSearch] = useState('')
  const [supplierSelected, setSupplierSelected] = useState<Set<number>>(new Set())

  const { data: businesses } = useGetBusinessesQuery(
    { page: 1, pageSize: 500, q: undefined },
    {
      skip:
        !isSuperAdmin ||
        (kind !== 'trial' &&
          kind !== 'pl' &&
          kind !== 'ledger' &&
          kind !== 'bs' &&
          kind !== 'customer' &&
          kind !== 'supplier' &&
          kind !== 'daily-cash-flow'),
    },
  )
  const { data: trialStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: trialBusinessId ?? undefined },
    { skip: !isSuperAdmin || kind !== 'trial' || !trialBusinessId },
  )

  const plStationsBusinessId = kind === 'pl' ? (isSuperAdmin ? (plBusinessId ?? 0) : authBusinessId) : 0
  const { data: plStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: plStationsBusinessId || undefined },
    { skip: kind !== 'pl' || plStationsBusinessId <= 0 },
  )
  const ledgerStationsBusinessId =
    kind === 'ledger' || kind === 'daily-cash-flow' ? (isSuperAdmin ? (ledgerBusinessId ?? 0) : authBusinessId) : 0
  const { data: ledgerStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: ledgerStationsBusinessId || undefined },
    { skip: (kind !== 'ledger' && kind !== 'daily-cash-flow') || ledgerStationsBusinessId <= 0 },
  )
  const bsStationsBusinessId = kind === 'bs' ? (isSuperAdmin ? (bsBusinessId ?? 0) : authBusinessId) : 0
  const { data: bsStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: bsStationsBusinessId || undefined },
    { skip: kind !== 'bs' || bsStationsBusinessId <= 0 },
  )
  const customerStationsBusinessId =
    kind === 'customer' ? (isSuperAdmin ? (customerBusinessId ?? 0) : authBusinessId) : 0
  const { data: customerStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: customerStationsBusinessId || undefined },
    { skip: kind !== 'customer' || customerStationsBusinessId <= 0 },
  )
  const supplierStationsBusinessId =
    kind === 'supplier' ? (isSuperAdmin ? (supplierBusinessId ?? 0) : authBusinessId) : 0
  const { data: supplierStations } = useGetStationsQuery(
    { page: 1, pageSize: 500, businessId: supplierStationsBusinessId || undefined },
    { skip: kind !== 'supplier' || supplierStationsBusinessId <= 0 },
  )

  useEffect(() => {
    if (!isSuperAdmin || kind !== 'trial') return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setTrialBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])

  useEffect(() => {
    if (!isSuperAdmin || kind !== 'pl') return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setPlBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])
  useEffect(() => {
    if (!isSuperAdmin || (kind !== 'ledger' && kind !== 'daily-cash-flow')) return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setLedgerBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])
  useEffect(() => {
    if (!isSuperAdmin || kind !== 'bs') return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setBsBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])
  useEffect(() => {
    if (!isSuperAdmin || kind !== 'customer') return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setCustomerBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])
  useEffect(() => {
    if (!isSuperAdmin || kind !== 'supplier') return
    const items = businesses?.items ?? []
    if (items.length === 0) return
    setSupplierBusinessId((prev) => {
      if (prev != null && items.some((b) => b.id === prev)) return prev
      return items[0].id
    })
  }, [isSuperAdmin, kind, businesses?.items])

  const effectiveBusinessId = isSuperAdmin ? (trialBusinessId ?? 0) : authBusinessId
  const effectivePlBusinessId = isSuperAdmin ? (plBusinessId ?? 0) : authBusinessId
  const effectiveLedgerBusinessId = isSuperAdmin ? (ledgerBusinessId ?? 0) : authBusinessId
  const effectiveBsBusinessId = isSuperAdmin ? (bsBusinessId ?? 0) : authBusinessId
  const effectiveCustomerBusinessId = isSuperAdmin ? (customerBusinessId ?? 0) : authBusinessId
  const effectiveSupplierBusinessId = isSuperAdmin ? (supplierBusinessId ?? 0) : authBusinessId
  const { data: ledgerAccounts } = useGetAccountsQuery(
    { page: 1, pageSize: 500, businessId: effectiveLedgerBusinessId > 0 ? effectiveLedgerBusinessId : undefined },
    { skip: (kind !== 'ledger' && kind !== 'daily-cash-flow') || effectiveLedgerBusinessId <= 0 },
  )
  const { data: customerAccounts } = useGetAccountsQuery(
    { page: 1, pageSize: 500, businessId: effectiveCustomerBusinessId > 0 ? effectiveCustomerBusinessId : undefined },
    { skip: kind !== 'customer' || effectiveCustomerBusinessId <= 0 },
  )
  const { data: supplierAccounts } = useGetAccountsQuery(
    { page: 1, pageSize: 500, businessId: effectiveSupplierBusinessId > 0 ? effectiveSupplierBusinessId : undefined },
    { skip: kind !== 'supplier' || effectiveSupplierBusinessId <= 0 },
  )

  const trial = useGetTrialBalanceReportQuery(
    {
      businessId: effectiveBusinessId,
      from: from || undefined,
      to: to || undefined,
      stationId: reportStationId(trialStationId),
    },
    { skip: kind !== 'trial' || effectiveBusinessId <= 0 || needsReportStation },
  )

  const ledger = useGetGeneralLedgerReportQuery(
    {
      businessId: effectiveLedgerBusinessId,
      accountId: ledgerAccountId ?? 0,
      from: from || undefined,
      to: to || undefined,
      stationId: reportStationId(ledgerStationId),
    },
    {
      skip:
        (kind !== 'ledger' && kind !== 'daily-cash-flow') ||
        effectiveLedgerBusinessId <= 0 ||
        !ledgerAccountId ||
        needsReportStation,
    },
  )
  const pl = useGetProfitLossReportQuery(
    {
      businessId: effectivePlBusinessId,
      from: from || undefined,
      to: to || undefined,
      stationId: reportStationId(plStationId),
    },
    { skip: kind !== 'pl' || effectivePlBusinessId <= 0 || needsReportStation },
  )
  const bs = useGetBalanceSheetReportQuery(
    {
      businessId: effectiveBsBusinessId,
      to: to || undefined,
      stationId: reportStationId(bsStationId),
    },
    { skip: kind !== 'bs' || effectiveBsBusinessId <= 0 || needsReportStation },
  )
  const customer = useGetCustomerBalancesReportQuery(
    {
      businessId: customerApplied?.businessId ?? 0,
      stationId: customerApplied?.stationId,
      from: customerApplied?.from,
      to: customerApplied?.to,
      receivableAccountId: customerApplied?.receivableAccountId ?? 0,
    },
    {
      skip:
        kind !== 'customer' ||
        !customerApplied ||
        customerApplied.businessId <= 0 ||
        customerApplied.receivableAccountId <= 0 ||
        needsReportStation,
    },
  )
  const supplier = useGetSupplierBalancesReportQuery(
    {
      businessId: supplierApplied?.businessId ?? 0,
      stationId: supplierApplied?.stationId,
      from: supplierApplied?.from,
      to: supplierApplied?.to,
      payableAccountId: supplierApplied?.payableAccountId ?? 0,
    },
    {
      skip:
        kind !== 'supplier' ||
        !supplierApplied ||
        supplierApplied.businessId <= 0 ||
        supplierApplied.payableAccountId <= 0 ||
        needsReportStation,
    },
  )

  const businessOptions: SelectOption[] = useMemo(
    () => (businesses?.items ?? []).map((b) => ({ value: String(b.id), label: b.name })),
    [businesses?.items],
  )
  const stationOptions: SelectOption[] = useMemo(
    () => (trialStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [trialStations?.items],
  )
  const plStationOptions: SelectOption[] = useMemo(
    () => (plStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [plStations?.items],
  )
  const ledgerStationOptions: SelectOption[] = useMemo(
    () => (ledgerStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [ledgerStations?.items],
  )
  const bsStationOptions: SelectOption[] = useMemo(
    () => (bsStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [bsStations?.items],
  )
  const customerStationOptions: SelectOption[] = useMemo(
    () => (customerStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [customerStations?.items],
  )
  const supplierStationOptions: SelectOption[] = useMemo(
    () => (supplierStations?.items ?? []).map((s) => ({ value: String(s.id), label: s.name })),
    [supplierStations?.items],
  )
  const customerAccountItemsFiltered = useMemo(
    () => filterAccountsForViewer(customerAccounts?.items, role, authBusinessIdRaw),
    [customerAccounts?.items, role, authBusinessIdRaw],
  )
  const supplierAccountItemsFiltered = useMemo(
    () => filterAccountsForViewer(supplierAccounts?.items, role, authBusinessIdRaw),
    [supplierAccounts?.items, role, authBusinessIdRaw],
  )
  const ledgerAccountItemsFiltered = useMemo(() => {
    const scoped = filterAccountsForFinancialReportsPicker(
      ledgerAccounts?.items,
      role,
      authBusinessIdRaw,
      effectiveLedgerBusinessId,
    )
    return filterBusinessLeafAccounts(scoped)
  }, [ledgerAccounts?.items, role, authBusinessIdRaw, effectiveLedgerBusinessId])
  const receivableAccountOptions: SelectOption[] = useMemo(
    () =>
      customerAccountItemsFiltered
        .filter((a) => isAccountsReceivable(a))
        .map((a) => ({ value: String(a.id), label: `${a.code} — ${a.name}` })),
    [customerAccountItemsFiltered],
  )
  const payableAccountOptions: SelectOption[] = useMemo(
    () =>
      supplierAccountItemsFiltered
        .filter((a) => isAccountsPayable(a))
        .map((a) => ({ value: String(a.id), label: `${a.code} — ${a.name}` })),
    [supplierAccountItemsFiltered],
  )
  const ledgerAccountOptions: SelectOption[] = useMemo(
    () => ledgerAccountItemsFiltered.map((a) => ({ value: String(a.id), label: `${a.code} - ${a.name}` })),
    [ledgerAccountItemsFiltered],
  )
  useEffect(() => {
    if (kind !== 'ledger' && kind !== 'daily-cash-flow') return
    const items = ledgerAccountItemsFiltered
    if (items.length === 0) return
    setLedgerAccountId((prev) => {
      if (prev != null && items.some((a) => a.id === prev)) return prev
      return items[0].id
    })
  }, [kind, ledgerAccountItemsFiltered])

  const trialRowsAll = useMemo((): TrialBalanceRow[] => {
    const raw = trial.data ?? []
    return raw.map((r: { accountId: number; code: string; name: string; debit: number; credit: number; balance: number }) => ({
      id: r.accountId,
      code: r.code,
      name: r.name,
      debit: r.debit,
      credit: r.credit,
      balance: r.balance,
    }))
  }, [trial.data])

  const trialRowsFiltered = useMemo(() => {
    const q = trialSearch.trim().toLowerCase()
    if (!q) return trialRowsAll
    return trialRowsAll.filter(
      (r) => r.code.toLowerCase().includes(q) || r.name.toLowerCase().includes(q),
    )
  }, [trialRowsAll, trialSearch])

  const trialRowsPage = useMemo(() => {
    const start = (trialPage - 1) * trialPageSize
    return trialRowsFiltered.slice(start, start + trialPageSize)
  }, [trialRowsFiltered, trialPage, trialPageSize])
  const trialTotals = useMemo(() => {
    return trialRowsFiltered.reduce(
      (acc, row) => {
        acc.debit += row.debit
        acc.credit += row.credit
        return acc
      },
      { debit: 0, credit: 0 },
    )
  }, [trialRowsFiltered])

  const plPeriodLabel = formatReportPeriod(from, to)
  const bsPeriodLabel = formatReportPeriod('', to)
  const ledgerRows = useMemo(() => {
    let running = 0
    const rows = (ledger.data ?? []).map((r: any, i: number) => {
      const debit = Number(r.debit ?? 0)
      const credit = Number(r.credit ?? 0)
      running += debit - credit
      return {
        id: i + 1,
        date: r.date,
        description: r.description ?? '—',
        debit,
        credit,
        balance: running,
      }
    })
    return [
      { id: 0, date: from || null, description: 'Opening Balance', debit: 0, credit: 0, balance: 0 },
      ...rows,
    ]
  }, [ledger.data, from])

  interface DailyCashFlowRow {
    id: string
    dateLabel: string
    totalDebit: number
    totalCredit: number
    netMovement: number
    endingBalance: number
  }

  const dailyCashFlowRows = useMemo((): DailyCashFlowRow[] => {
    if (kind !== 'daily-cash-flow') return []
    const raw = ledger.data ?? []
    const byDay = new Map<string, { debit: number; credit: number }>()
    for (const r of raw) {
      if (!r?.date) continue
      const d = new Date(r.date as string)
      if (Number.isNaN(d.getTime())) continue
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      const debit = Number(r.debit ?? 0)
      const credit = Number(r.credit ?? 0)
      const cur = byDay.get(key) ?? { debit: 0, credit: 0 }
      cur.debit += debit
      cur.credit += credit
      byDay.set(key, cur)
    }
    const keys = [...byDay.keys()].sort()
    let running = 0
    return keys.map((key) => {
      const { debit, credit } = byDay.get(key)!
      const net = debit - credit
      running += net
      const [y, m, da] = key.split('-').map(Number)
      const label = new Date(y, m - 1, da).toLocaleDateString(undefined, { dateStyle: 'medium' })
      return {
        id: key,
        dateLabel: label,
        totalDebit: debit,
        totalCredit: credit,
        netMovement: net,
        endingBalance: running,
      }
    })
  }, [kind, ledger.data])

  function customerBalanceStableId(name: string): number {
    let h = 0
    for (let i = 0; i < name.length; i++) h = (Math.imul(31, h) + name.charCodeAt(i)) | 0
    const x = Math.abs(h) % 2147483647
    return x === 0 ? 1 : x
  }

  const customerRowsAll = useMemo((): CustomerBalanceRow[] => {
    const raw = customer.data ?? []
    return [...raw]
      .sort((a: { customer?: string }, b: { customer?: string }) =>
        String(a.customer ?? '').localeCompare(String(b.customer ?? '')),
      )
      .map((r: { code?: string; customer?: string; givenAmount?: number; paidAmount?: number; balance?: number }) => {
        const name = String(r.customer ?? '')
        return {
          id: customerBalanceStableId(name),
          code: String(r.code ?? '—'),
          name,
          given: Number(r.givenAmount ?? 0),
          paid: Number(r.paidAmount ?? 0),
          balance: Number(r.balance ?? 0),
        }
      })
  }, [customer.data])

  const customerRowsFiltered = useMemo(() => {
    const q = customerSearch.trim().toLowerCase()
    if (!q) return customerRowsAll
    return customerRowsAll.filter(
      (r) => r.name.toLowerCase().includes(q) || r.code.toLowerCase().includes(q),
    )
  }, [customerRowsAll, customerSearch])

  const customerRowsPage = useMemo(() => {
    const start = (customerPage - 1) * customerPageSize
    return customerRowsFiltered.slice(start, start + customerPageSize)
  }, [customerRowsFiltered, customerPage, customerPageSize])

  const customerTotals = useMemo(
    () =>
      customerRowsFiltered.reduce(
        (acc, row) => {
          acc.given += row.given
          acc.paid += row.paid
          acc.balance += row.balance
          return acc
        },
        { given: 0, paid: 0, balance: 0 },
      ),
    [customerRowsFiltered],
  )

  const customerCols: Column<CustomerBalanceRow>[] = [
    { key: 'code', header: 'Code' },
    { key: 'name', header: 'Name' },
    { key: 'given', header: 'Given', render: (r) => formatDecimal(r.given) },
    { key: 'paid', header: 'Paid', render: (r) => formatDecimal(r.paid) },
    { key: 'balance', header: 'Balance', render: (r) => formatDecimal(r.balance) },
  ]

  const supplierRowsAll = useMemo((): CustomerBalanceRow[] => {
    const raw = supplier.data ?? []
    return [...raw]
      .sort((a: { supplier?: string }, b: { supplier?: string }) =>
        String(a.supplier ?? '').localeCompare(String(b.supplier ?? '')),
      )
      .map((r: { code?: string; supplier?: string; givenAmount?: number; paidAmount?: number; balance?: number }) => {
        const name = String(r.supplier ?? '')
        return {
          id: customerBalanceStableId(`sup:${name}`),
          code: String(r.code ?? '—'),
          name,
          given: Number(r.givenAmount ?? 0),
          paid: Number(r.paidAmount ?? 0),
          balance: Number(r.balance ?? 0),
        }
      })
  }, [supplier.data])

  const supplierRowsFiltered = useMemo(() => {
    const q = supplierSearch.trim().toLowerCase()
    if (!q) return supplierRowsAll
    return supplierRowsAll.filter(
      (r) => r.name.toLowerCase().includes(q) || r.code.toLowerCase().includes(q),
    )
  }, [supplierRowsAll, supplierSearch])

  const supplierRowsPage = useMemo(() => {
    const start = (supplierPage - 1) * supplierPageSize
    return supplierRowsFiltered.slice(start, start + supplierPageSize)
  }, [supplierRowsFiltered, supplierPage, supplierPageSize])

  const supplierTotals = useMemo(
    () =>
      supplierRowsFiltered.reduce(
        (acc, row) => {
          acc.given += row.given
          acc.paid += row.paid
          acc.balance += row.balance
          return acc
        },
        { given: 0, paid: 0, balance: 0 },
      ),
    [supplierRowsFiltered],
  )

  const supplierCols: Column<CustomerBalanceRow>[] = customerCols

  if (kind === 'ledger') {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">General Ledger</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(ledgerBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setLedgerBusinessId(opt ? Number(opt.value) : null)
                    setLedgerStationId(null)
                    setLedgerAccountId(null)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            <div className="w-full min-w-0 lg:w-64">
              <label className="mb-1 block text-sm font-medium text-slate-700">Account</label>
              <FormSelect
                options={ledgerAccountOptions}
                value={ledgerAccountOptions.find((o) => o.value === String(ledgerAccountId ?? '')) ?? null}
                onChange={(opt) => setLedgerAccountId(opt ? Number(opt.value) : null)}
                placeholder="Select account"
                isDisabled={effectiveLedgerBusinessId <= 0}
              />
            </div>
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={ledgerStationOptions}
                  value={ledgerStationOptions.find((o) => o.value === String(ledgerStationId ?? '')) ?? null}
                  onChange={(opt) => setLedgerStationId(opt ? Number(opt.value) : null)}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectiveLedgerBusinessId <= 0 || (isSuperAdmin && !ledgerBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
        </div>

        {effectiveLedgerBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to load the ledger.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : !ledgerAccountId ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select an account to load the ledger.</p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
            <table className="min-w-full divide-y divide-slate-200 text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left">
                  <th className="px-4 py-3 font-semibold text-slate-600">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Description</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Debit</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Credit</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledger.isFetching && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                      Loading...
                    </td>
                  </tr>
                )}
                {!ledger.isFetching &&
                  ledgerRows.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-2.5 text-slate-700">{r.date ? new Date(r.date).toLocaleDateString() : '—'}</td>
                      <td className="px-4 py-2.5 text-slate-800">{r.description}</td>
                      <td className="px-4 py-2.5 text-slate-700">{r.debit === 0 ? '' : formatDecimal(r.debit)}</td>
                      <td className="px-4 py-2.5 text-slate-700">{r.credit === 0 ? '' : formatDecimal(r.credit)}</td>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{formatDecimal(r.balance)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    )
  }

  if (kind === 'daily-cash-flow') {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">Daily cash flow report</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>
        <p className="text-sm text-slate-600">
          Net movement by calendar day for the selected account (typically cash or bank). Uses the same journal lines as
          the general ledger, aggregated per day.
        </p>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(ledgerBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setLedgerBusinessId(opt ? Number(opt.value) : null)
                    setLedgerStationId(null)
                    setLedgerAccountId(null)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            <div className="w-full min-w-0 lg:w-64">
              <label className="mb-1 block text-sm font-medium text-slate-700">Account</label>
              <FormSelect
                options={ledgerAccountOptions}
                value={ledgerAccountOptions.find((o) => o.value === String(ledgerAccountId ?? '')) ?? null}
                onChange={(opt) => setLedgerAccountId(opt ? Number(opt.value) : null)}
                placeholder="Select account"
                isDisabled={effectiveLedgerBusinessId <= 0}
              />
            </div>
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={ledgerStationOptions}
                  value={ledgerStationOptions.find((o) => o.value === String(ledgerStationId ?? '')) ?? null}
                  onChange={(opt) => setLedgerStationId(opt ? Number(opt.value) : null)}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectiveLedgerBusinessId <= 0 || (isSuperAdmin && !ledgerBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
        </div>

        {effectiveLedgerBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to run the report.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : !ledgerAccountId ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select an account to load daily cash flow.</p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
            <table className="min-w-full divide-y divide-slate-200 text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left">
                  <th className="px-4 py-3 font-semibold text-slate-600">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Debit total</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Credit total</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Net (debit − credit)</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Cumulative in period</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledger.isFetching && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                      Loading...
                    </td>
                  </tr>
                )}
                {!ledger.isFetching &&
                  dailyCashFlowRows.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-2.5 text-slate-800">{r.dateLabel}</td>
                      <td className="px-4 py-2.5 text-slate-700">{r.totalDebit === 0 ? '—' : formatDecimal(r.totalDebit)}</td>
                      <td className="px-4 py-2.5 text-slate-700">{r.totalCredit === 0 ? '—' : formatDecimal(r.totalCredit)}</td>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{formatDecimal(r.netMovement)}</td>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{formatDecimal(r.endingBalance)}</td>
                    </tr>
                  ))}
                {!ledger.isFetching && dailyCashFlowRows.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                      No journal lines in this date range for the selected account.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    )
  }

  if (kind === 'pl') {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">Profit &amp; Loss</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(plBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setPlBusinessId(opt ? Number(opt.value) : null)
                    setPlStationId(null)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={plStationOptions}
                  value={plStationOptions.find((o) => o.value === String(plStationId ?? '')) ?? null}
                  onChange={(opt) => setPlStationId(opt ? Number(opt.value) : null)}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectivePlBusinessId <= 0 || (isSuperAdmin && !plBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Assign accounts to chart types <strong>Income</strong>, <strong>COGS</strong>, or <strong>Expense</strong> for them to appear here.{' '}
            <strong>Cash</strong> and other balance-sheet accounts affect the trial balance, not this report.
          </p>
        </div>

        {effectivePlBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to load the report.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : (
          <ProfitLossReportView data={pl.data} isLoading={pl.isFetching} periodLabel={plPeriodLabel} />
        )}
      </div>
    )
  }

  const trialCols: Column<TrialBalanceRow>[] = [
    { key: 'code', header: 'Code' },
    { key: 'name', header: 'Name' },
    {
      key: 'debit',
      header: 'Debit',
      render: (r) => formatDecimal(r.debit),
    },
    {
      key: 'credit',
      header: 'Credit',
      render: (r) => formatDecimal(r.credit),
    },
    {
      key: 'balance',
      header: 'Balance',
      render: (r) => formatDecimal(r.balance),
    },
  ]

  if (kind === 'trial') {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(trialBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setTrialBusinessId(opt ? Number(opt.value) : null)
                    setTrialStationId(null)
                    setTrialPage(1)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={stationOptions}
                  value={stationOptions.find((o) => o.value === String(trialStationId ?? '')) ?? null}
                  onChange={(opt) => {
                    setTrialStationId(opt ? Number(opt.value) : null)
                    setTrialPage(1)
                  }}
                  placeholder="All stations"
                  isClearable
                  isDisabled={!trialBusinessId}
                />
              </div>
            )}
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={from}
                onChange={(e) => {
                  setFrom(e.target.value)
                  setTrialPage(1)
                }}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={to}
                onChange={(e) => {
                  setTo(e.target.value)
                  setTrialPage(1)
                }}
              />
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Report loads automatically for the selected business. Use <strong>From</strong> / <strong>To</strong> to limit by
            journal entry date (optional).
          </p>
        </div>

        {effectiveBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to load the trial balance.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : (
          <DataTable<TrialBalanceRow>
            readOnly
            title="Trial balance"
            extraToolbar={
              <button
                type="button"
                className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                onClick={() => window.print()}
              >
                Print / Export
              </button>
            }
            rows={trialRowsPage}
            totalCount={trialRowsFiltered.length}
            page={trialPage}
            pageSize={trialPageSize}
            onPageChange={setTrialPage}
            onPageSizeChange={(n) => {
              setTrialPageSize(n)
              setTrialPage(1)
            }}
            search={trialSearch}
            onSearchChange={(q) => {
              setTrialSearch(q)
              setTrialPage(1)
            }}
            columns={trialCols}
            isLoading={trial.isFetching}
            selectedIds={trialSelected}
            onSelectedIdsChange={setTrialSelected}
            belowTable={
              <div className="flex justify-end gap-8 border-t border-slate-100 px-4 py-3 text-sm font-semibold text-slate-700">
                <span>Debit total: {formatDecimal(trialTotals.debit)}</span>
                <span>Credit total: {formatDecimal(trialTotals.credit)}</span>
              </div>
            }
            onDeleteOne={() => {}}
            onDeleteSelected={() => {}}
          />
        )}
      </div>
    )
  }

  if (kind === 'bs') {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">Balance sheet</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(bsBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setBsBusinessId(opt ? Number(opt.value) : null)
                    setBsStationId(null)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={bsStationOptions}
                  value={bsStationOptions.find((o) => o.value === String(bsStationId ?? '')) ?? null}
                  onChange={(opt) => setBsStationId(opt ? Number(opt.value) : null)}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectiveBsBusinessId <= 0 || (isSuperAdmin && !bsBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">As of</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Balances for <strong>Asset</strong>, <strong>Liability</strong>, and <strong>Equity</strong> accounts through the selected date (optional).
          </p>
        </div>

        {effectiveBsBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to load the balance sheet.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : (
          <BalanceSheetReportView data={bs.data} isLoading={bs.isFetching} periodLabel={bsPeriodLabel} />
        )}
      </div>
    )
  }

  if (kind === 'customer') {
    const canRunCustomerView =
      effectiveCustomerBusinessId > 0 &&
      customerReceivableAccountId != null &&
      customerReceivableAccountId > 0 &&
      !needsReportStation

    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">Customer balances</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(customerBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setCustomerBusinessId(opt ? Number(opt.value) : null)
                    setCustomerStationId(null)
                    setCustomerReceivableAccountId(null)
                    setCustomerApplied(null)
                    setCustomerPage(1)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={customerStationOptions}
                  value={customerStationOptions.find((o) => o.value === String(customerStationId ?? '')) ?? null}
                  onChange={(opt) => {
                    setCustomerStationId(opt ? Number(opt.value) : null)
                    setCustomerPage(1)
                  }}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectiveCustomerBusinessId <= 0 || (isSuperAdmin && !customerBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 lg:w-72">
              <label className="mb-1 block text-sm font-medium text-slate-700">Receivable account</label>
              <FormSelect
                options={receivableAccountOptions}
                value={receivableAccountOptions.find((o) => o.value === String(customerReceivableAccountId ?? '')) ?? null}
                onChange={(opt) => {
                  setCustomerReceivableAccountId(opt ? Number(opt.value) : null)
                  setCustomerPage(1)
                }}
                placeholder="Select receivable account"
                isDisabled={effectiveCustomerBusinessId <= 0}
                isSearchable
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={customerFrom}
                onChange={(e) => setCustomerFrom(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={customerTo}
                onChange={(e) => setCustomerTo(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 lg:w-auto">
              <label className="mb-1 block text-sm font-medium text-transparent">View</label>
              <button
                type="button"
                disabled={!canRunCustomerView}
                onClick={() => {
                  if (!canRunCustomerView || customerReceivableAccountId == null) return
                  setCustomerApplied({
                    businessId: effectiveCustomerBusinessId,
                    stationId: reportStationId(customerStationId),
                    from: customerFrom.trim() || undefined,
                    to: customerTo.trim() || undefined,
                    receivableAccountId: customerReceivableAccountId,
                  })
                  setCustomerPage(1)
                }}
                className="w-full rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50 lg:w-auto"
              >
                View
              </button>
            </div>
          </div>
        </div>

        {effectiveCustomerBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to run customer balances.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : !customerApplied ? (
          <p className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
            Choose a receivable account, optional dates, then click <strong>View</strong> to load balances from <strong>journal entries</strong> on that account (lines with a customer subledger), for the selected period.
          </p>
        ) : (
          <DataTable<CustomerBalanceRow>
            readOnly
            title="Customer balances"
            rows={customerRowsPage}
            totalCount={customerRowsFiltered.length}
            page={customerPage}
            pageSize={customerPageSize}
            onPageChange={setCustomerPage}
            onPageSizeChange={(n) => {
              setCustomerPageSize(n)
              setCustomerPage(1)
            }}
            search={customerSearch}
            onSearchChange={(q) => {
              setCustomerSearch(q)
              setCustomerPage(1)
            }}
            columns={customerCols}
            isLoading={customer.isFetching}
            selectedIds={customerSelected}
            onSelectedIdsChange={setCustomerSelected}
            belowTable={
              <div className="flex justify-end gap-8 border-t border-slate-100 px-4 py-3 text-sm font-semibold text-slate-700">
                <span>Given total: {formatDecimal(customerTotals.given)}</span>
                <span>Paid total: {formatDecimal(customerTotals.paid)}</span>
                <span>Balance total: {formatDecimal(customerTotals.balance)}</span>
              </div>
            }
            onDeleteOne={() => {}}
            onDeleteSelected={() => {}}
          />
        )}
      </div>
    )
  }

  if (kind === 'supplier') {
    const canRunSupplierView =
      effectiveSupplierBusinessId > 0 &&
      supplierPayableAccountId != null &&
      supplierPayableAccountId > 0 &&
      !needsReportStation

    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold text-slate-900">Supplier balances</h1>
          <button
            type="button"
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            onClick={() => window.print()}
          >
            Print / Export
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:flex-wrap lg:items-end">
            {isSuperAdmin && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Business</label>
                <FormSelect
                  options={businessOptions}
                  value={businessOptions.find((o) => o.value === String(supplierBusinessId ?? '')) ?? null}
                  onChange={(opt) => {
                    setSupplierBusinessId(opt ? Number(opt.value) : null)
                    setSupplierStationId(null)
                    setSupplierPayableAccountId(null)
                    setSupplierApplied(null)
                    setSupplierPage(1)
                  }}
                  placeholder="Select business"
                />
              </div>
            )}
            {showStationPicker && (
              <div className="w-full min-w-0 lg:w-52">
                <label className="mb-1 block text-sm font-medium text-slate-700">Station</label>
                <FormSelect
                  options={supplierStationOptions}
                  value={supplierStationOptions.find((o) => o.value === String(supplierStationId ?? '')) ?? null}
                  onChange={(opt) => {
                    setSupplierStationId(opt ? Number(opt.value) : null)
                    setSupplierPage(1)
                  }}
                  placeholder="All stations"
                  isClearable
                  isDisabled={effectiveSupplierBusinessId <= 0 || (isSuperAdmin && !supplierBusinessId)}
                />
              </div>
            )}
            <div className="w-full min-w-0 lg:w-72">
              <label className="mb-1 block text-sm font-medium text-slate-700">Payable account</label>
              <FormSelect
                options={payableAccountOptions}
                value={payableAccountOptions.find((o) => o.value === String(supplierPayableAccountId ?? '')) ?? null}
                onChange={(opt) => {
                  setSupplierPayableAccountId(opt ? Number(opt.value) : null)
                  setSupplierPage(1)
                }}
                placeholder="Select payable account"
                isDisabled={effectiveSupplierBusinessId <= 0}
                isSearchable
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">From</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={supplierFrom}
                onChange={(e) => setSupplierFrom(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 sm:max-w-[11rem]">
              <label className="mb-1 block text-sm font-medium text-slate-700">To</label>
              <input
                type="date"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                value={supplierTo}
                onChange={(e) => setSupplierTo(e.target.value)}
              />
            </div>
            <div className="w-full min-w-0 lg:w-auto">
              <label className="mb-1 block text-sm font-medium text-transparent">View</label>
              <button
                type="button"
                disabled={!canRunSupplierView}
                onClick={() => {
                  if (!canRunSupplierView || supplierPayableAccountId == null) return
                  setSupplierApplied({
                    businessId: effectiveSupplierBusinessId,
                    stationId: reportStationId(supplierStationId),
                    from: supplierFrom.trim() || undefined,
                    to: supplierTo.trim() || undefined,
                    payableAccountId: supplierPayableAccountId,
                  })
                  setSupplierPage(1)
                }}
                className="w-full rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50 lg:w-auto"
              >
                View
              </button>
            </div>
          </div>
        </div>

        {effectiveSupplierBusinessId <= 0 && isSuperAdmin ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Select a business to run supplier balances.</p>
        ) : needsReportStation ? (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{reportStationBlockedMessage}</p>
        ) : !supplierApplied ? (
          <p className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
            Choose a payable account, optional dates, then click <strong>View</strong> to load balances (journal activity on that account with supplier subledger links).
          </p>
        ) : (
          <DataTable<CustomerBalanceRow>
            readOnly
            title="Supplier balances"
            rows={supplierRowsPage}
            totalCount={supplierRowsFiltered.length}
            page={supplierPage}
            pageSize={supplierPageSize}
            onPageChange={setSupplierPage}
            onPageSizeChange={(n) => {
              setSupplierPageSize(n)
              setSupplierPage(1)
            }}
            search={supplierSearch}
            onSearchChange={(q) => {
              setSupplierSearch(q)
              setSupplierPage(1)
            }}
            columns={supplierCols}
            isLoading={supplier.isFetching}
            selectedIds={supplierSelected}
            onSelectedIdsChange={setSupplierSelected}
            belowTable={
              <div className="flex justify-end gap-8 border-t border-slate-100 px-4 py-3 text-sm font-semibold text-slate-700">
                <span>Given total: {formatDecimal(supplierTotals.given)}</span>
                <span>Paid total: {formatDecimal(supplierTotals.paid)}</span>
                <span>Balance total: {formatDecimal(supplierTotals.balance)}</span>
              </div>
            }
            onDeleteOne={() => {}}
            onDeleteSelected={() => {}}
          />
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <p className="text-slate-600">Choose a financial report from the sidebar.</p>
    </div>
  )
}
